package com.achihoang.controller;

import com.achihoang.model.Category;
import com.achihoang.model.Post;
import com.achihoang.service.ICategoryService;
import com.achihoang.service.IPostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;


@Controller
public class CategoryController {

    @Autowired
    private ICategoryService ICategoryService;

    @Autowired
    private IPostService postServices;

    @GetMapping("/listCategory")
    public ModelAndView list(Pageable pageable) {
        Page<Category> categoryPage = ICategoryService.findAll(pageable);
        ModelAndView modelAndView = new ModelAndView("/category/list");
        modelAndView.addObject("list", categoryPage);
        return modelAndView;
    }

    @GetMapping("/createCategory")
    public ModelAndView showCreateForm() {
        ModelAndView modelAndView = new ModelAndView("/category/create");
        modelAndView.addObject("create", new Category());
        return modelAndView;
    }

    @PostMapping("/createCategory")
    public ModelAndView saveCreate(@Valid @ModelAttribute("create") Category category, BindingResult bindingResult) {
        if (bindingResult.hasFieldErrors()) {
            ModelAndView modelAndView = new ModelAndView("/category/create");
            return modelAndView;
        } else {
            ICategoryService.save(category);
            ModelAndView modelAndView = new ModelAndView("/category/create");
            modelAndView.addObject("create", new Category());
            modelAndView.addObject("message", "New category created successfully");
            return modelAndView;
        }
    }

    @GetMapping("/editCategory/{id}")
    public ModelAndView showEditForm(@PathVariable Long id) {
        Category category = ICategoryService.findById(id);
        if (category != null) {
            ModelAndView modelAndView = new ModelAndView("/category/edit");
            modelAndView.addObject("edit", category);
            return modelAndView;
        } else {
            ModelAndView modelAndView = new ModelAndView("/error/404");
            return modelAndView;
        }
    }

    @PostMapping("/editCategory")
    public ModelAndView Edit(@Valid @ModelAttribute("edit") Category category, BindingResult bindingResult) {
        if (bindingResult.hasFieldErrors()) {
            ModelAndView modelAndView = new ModelAndView("/category/edit");
            return modelAndView;
        }
        ICategoryService.save(category);
        ModelAndView modelAndView = new ModelAndView("/category/edit");
        modelAndView.addObject("edit", category);
        modelAndView.addObject("message", "category updated successfully");
        return modelAndView;
    }

    @GetMapping("/deleteCategory/{id}")
    public ModelAndView showDeleteForm(@PathVariable Long id) {
        Category category = ICategoryService.findById(id);
        if (category != null) {
            ModelAndView modelAndView = new ModelAndView("/category/delete");
            modelAndView.addObject("delete", category);
            return modelAndView;
        } else {
            ModelAndView modelAndView = new ModelAndView("/error/404");
            return modelAndView;
        }
    }

    @PostMapping("/deleteCategory")
    public String delete(@ModelAttribute("delete") Category category) {
        ICategoryService.delete(category.getId());
        return "redirect:listCategory";
    }

    @GetMapping("/viewCategory/{id}")
    public ModelAndView view(@PathVariable("id") Long id) {
        Category category = ICategoryService.findById(id);
        if (category == null) {
            return new ModelAndView("/error/404");
        }
        Iterable<Post> posts = postServices.findAllByCategory(category);
        ModelAndView modelAndView = new ModelAndView("/category/view");
        modelAndView.addObject("view", category);
        modelAndView.addObject("posts", posts);
        return modelAndView;
    }
}
